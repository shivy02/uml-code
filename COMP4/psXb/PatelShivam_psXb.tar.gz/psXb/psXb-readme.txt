/**********************************************************************
 *                                                  
 *  PS3b: StringSound implementation and SFML audio output 
 **********************************************************************/

Name: Shivam Patel

Hours to complete assignment : 2 hours

/**********************************************************************

I used the wrong vector in one of my functions and put the right one.
The code now works.