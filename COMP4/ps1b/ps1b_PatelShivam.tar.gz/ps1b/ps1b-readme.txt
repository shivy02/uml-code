/**********************************************************************
 * ps1b-readme.txt
 **********************************************************************/

Name: Shivam Patel
Hours to complete assignment: 3hr
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.

 **********************************************************************/

This assignment used the functions from the Linear Feedback Shift register
in order to encrypt an image and the decrypt it. I was able to write the
function transform that changed all of the pixels in the original image.
Running the code on the output file then decrypted the image.




/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
Rami Hammoud, Dev Patel

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/

One problem that I encountered was that the output file wasn't being
saved from the right image that I transformed but instead the original
so the output was just the original image.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/