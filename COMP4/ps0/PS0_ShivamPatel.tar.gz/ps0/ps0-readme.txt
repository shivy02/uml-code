/**********************************************************************
 *  ps0-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Your name: Shivam Patel

Operating system you're using (Linux, OS X, or Windows): OS X

IDE or text editor you're using: Visual Studio Code

Hours to complete assignment: 1hr

/**********************************************************************
 *  Part of Assignment 0 is to read the collaboration policy in syllabus.
 *  
 *  If you haven't done this, please do so now.
 *
 *  Read the University policy Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100-200
 * words.
 *
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.
 **********************************************************************/

 Out of the six examples of academic misconduct outlined in the academic
 integrity policy, the one that I think applies the most to this class is
 claiming credit for the work or efforts of another without authorization
 or citation. I believe that this applies the most in this class because 
 when programming, its easy to take the fast route and copy and paste the
 work of others in order to get something done. The only problem with this
 however, is the fact that you do not take the steps to come to the solution
 and in turn, do not learn anything. If given another task that is similar
 it would be harder to solve it if you didn't take the necessary steps in
 the previous task.


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/