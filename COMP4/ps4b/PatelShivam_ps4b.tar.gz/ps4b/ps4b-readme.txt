/**********************************************************************
 *                                                  
 *  PS3b: StringSound implementation and SFML audio output 
 **********************************************************************/

Name: Shivam Patel

Hours to complete assignment : 2 hours

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/

Yes I completed the whole assignment successfully. All of the functions
work because test cases were written in order to test them. All of these
cases passed.


/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  
 **********************************************************************/

 None of the extra credit parts were completed.

/**********************************************************************
 *  Did you implement exseptions to check your StringSound 
 *	implementation?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/
I did not implement exceptions in the StringSound implementation.


/**********************************************************************
 *  Did you implement lambda expression?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/
 
I did not implement lambda expressions in my code.


/**********************************************************************
 *  Did your code pass cpplint?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/

yes my code passes cpplint. I ran cpplint on each of the files seperately

/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.
 **********************************************************************/
Stack Overflow


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
No serious problems were encountered

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/