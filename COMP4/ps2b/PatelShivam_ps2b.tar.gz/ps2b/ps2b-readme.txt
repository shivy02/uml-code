/**********************************************************************
 *  N-Body Simulation ps2b-readme.txt template
 **********************************************************************/

Name: Shivam Patel

Hours to complete assignment: 10hours
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/

I was not able to make the planets move properly because there was a problem
with how my values were being calculated.



/**********************************************************************
 *  If you created your own universe for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/




/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
Stack OverFlow, Discord, Office Hours

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
A major problem that I was not able to fix was that all of my planets kept
appearing bunched up in the corner. This was an issue with my calculations
and where I was storing them. There are still bugs because the planets move
across the top of the window.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/