/**
 * @file Universe.cpp
 * @author Shivam Patel (Shivam_Patel3@student.uml.edu)
 * @brief 
 * @version 0.1
 * @date 2022-02-15
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "Universe.h"

double Universe::getRadius()const{
    return radius;
}

int Universe::getNumBodies()const{
    return numBodies;
}

void Universe::size(int x, int y){
    for(int i=0; i < getNumBodies(); i++){
        this->universe[i]->setPos(x,y,radius);
    }
}

CelestialBody Universe::getPlanet(int i){
    return *(universe[i]);
}

void Universe::step(double t){

    double F, dx, dy, M1, M2, x1, x2, y1, y2;
    double vX, vY;
    double FNx = 0.0;
    double FNy = 0.0;

    // double r = 0.0;

    for (int i = 0; i < numBodies; i++){
        for (int j = 0; j < numBodies; j++){
        
            if(this->universe[i] != this->universe[j]){
                x2 = this->universe[j]->getx();
                x1 = this->universe[i]->getx();

                y2 = this->universe[j]->gety();
                y1 = this->universe[i]->gety();

                dx = x2 - x1;
                dy = y2 - y1;

                double r2 = (dx * dx) + (dy * dy);

                //calc radius
                this->universe[i]->setR(sqrt(r2));


                //calculate Force
                M1 = this->universe[i]->getMass();
                M2 = this->universe[j]->getMass();
                F = (G * M1 * M2) / r2;

                this->universe[i]->setForceY(F * (dy / this->universe[i]->getR()));
                this->universe[i]->setForceX(F * (dx / this->universe[i]->getR()));

                FNx += this->universe[i]->getForceX();
                FNy += this->universe[i]->getForceY();
            }
        }

        //set Acceleration X and Acceleration Y for 1st planet
        this->universe[i]->setAccX(FNx / this->universe[i]->getMass());
        this->universe[i]->setAccY(FNy / this->universe[i]->getMass());

        vX = this->universe[i]->getXVelocity();
        vY = this->universe[i]->getYVelocity();

        this->universe[i]->setXYVelocity((vX + (this->universe[i]->getAccX() * t)), (vY + (this->universe[i]->getAccY() * t)));

        this->universe[i]->setXpos(universe[i]->getx() + (t * universe[i]->getXVelocity()));
        this->universe[i]->setYpos(universe[i]->gety() + (t * universe[i]->getYVelocity()));

        this->universe[i]->setPos(this->universe[i]->getx() + (this->universe[i]->getXVelocity() * t), this->universe[i]->gety() + (this->universe[i]->getYVelocity() * t), this->universe[i]->getR());

        std::cout << this->universe[i]->getx() << " " << this->universe[i]->gety() << " " << this->universe[i]->getXVelocity() << " " << this->universe[i]->getYVelocity() << std::endl;
    }

}
