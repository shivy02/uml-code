#ifndef STATUS_H
#define STATUS_H
enum status {
        FAILURE = 0,
        SUCCESS = 1
};
typedef enum status Status;

enum boolean{FALSE, TRUE};
typedef enum boolean Boolean;
#endif
