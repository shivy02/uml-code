#ifndef GENERIC_H
#define GENERIC_H

typedef void* Item;

#endif