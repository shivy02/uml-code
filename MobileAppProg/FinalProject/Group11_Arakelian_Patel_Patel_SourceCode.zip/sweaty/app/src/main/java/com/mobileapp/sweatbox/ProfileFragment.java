/*
FileName: ProfileFragment.java
Purpose:The profile fragment was created using EditTexts and TextViews to allow for the user to enter information including their Name, Height, Weight, Birthday and Calorie Goal. This portion of the app is a page to keep track of progress throughout one’s workout journey. It uses a view Model to save the data even when the app is closed. The view Model was a straightforward way to implement this compared to other ways we learned. It also uses binding and the createTextWatcher function to set the viewModels fields to save the EditTexts entered by the user.
*/

package com.mobileapp.sweatbox;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.mobileapp.sweatbox.databinding.FragmentProfileBinding;

public class ProfileFragment extends Fragment {

    private FragmentProfileBinding binding;
    private SweatyViewModel viewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        viewModel = new ViewModelProvider(requireActivity()).get(SweatyViewModel.class);
        //The lines above set up view binding and intialize a viewModel object to create later.

        binding.name.setText(viewModel.getName());
        binding.height.setText(viewModel.getHeight());
        binding.weight.setText(viewModel.getWeight());
        binding.birthday.setText(viewModel.getBirthday());
        binding.calorieGoal.setText(viewModel.getCalorieGoal());
        //Retrieving edit Text values through the view model.

        binding.name.addTextChangedListener(createTextWatcher(SweatyViewModel.NAME));
        binding.height.addTextChangedListener(createTextWatcher(SweatyViewModel.HEIGHT));
        binding.weight.addTextChangedListener(createTextWatcher(SweatyViewModel.WEIGHT));
        binding.birthday.addTextChangedListener(createTextWatcher(SweatyViewModel.BIRTHDAY));
        binding.calorieGoal.addTextChangedListener(createTextWatcher(SweatyViewModel.CALORIE_GOAL));
        //Using the createTextWatcher function to save the information that is entered into the editTexts in the viewModel

        return view;
    }

    //Creates the creatTextWatcher built in function
    private TextWatcher createTextWatcher(final String field) {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                //Recieves the current string value and assigns it to the view model field that matches the correct case.
                String value = s.toString();
                switch (field) {
                    case SweatyViewModel.NAME:
                        viewModel.setName(value);
                        break;
                    case SweatyViewModel.HEIGHT:
                        viewModel.setHeight(value);
                        break;
                    case SweatyViewModel.WEIGHT:
                        viewModel.setWeight(value);
                        break;
                    case SweatyViewModel.BIRTHDAY:
                        viewModel.setBirthday(value);
                        break;
                    case SweatyViewModel.CALORIE_GOAL:
                        viewModel.setCalorieGoal(value);
                        break;
                }
            }

        };
    }
}