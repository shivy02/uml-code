/*
File Name: TimerFragment.java
Purpose: This file contains all of the code that runs the timer. It consists of
listeners for all of the buttons and dynamicallly generates lap times underneath
the timer by adding a new text view.
 */
package com.mobileapp.sweatbox;

import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

public class TimerFragment extends Fragment {
    private Chronometer stopwatch;
    private LinearLayout lapLayout;

    private SweatyViewModel sweatyViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        //get all of the binding and inflate the view
        View view = inflater.inflate(R.layout.fragment_timer, container, false);
        stopwatch = view.findViewById(R.id.chronometer);
        Button startButton = view.findViewById(R.id.startButton);
        Button pauseButton = view.findViewById(R.id.pauseButton);
        Button resetButton = view.findViewById(R.id.resetButton);
        Button lapButton = view.findViewById(R.id.lapButton);
        Button clearLapsButton = view.findViewById(R.id.clearLapsButton);
        lapLayout = view.findViewById(R.id.lapLayout);

        sweatyViewModel = new ViewModelProvider(this).get(SweatyViewModel.class);
        Log.d("DEBUG", "View inflated and elements are binded");

        //using saved instance state to bundle and retrieve values needed when the activity is restored.
        if (savedInstanceState != null) {
            sweatyViewModel.setStopwatchRunning(savedInstanceState.getBoolean("isStopwatchRunning"));

            long baseTime = savedInstanceState.getLong("baseTime");
            long offset = SystemClock.elapsedRealtime() - baseTime;

            if (sweatyViewModel.isStopwatchRunning()) {
                stopwatch.setBase(SystemClock.elapsedRealtime() - offset);
                stopwatch.start();
            } else {
                stopwatch.setBase(baseTime);
            }
        }

        //listener for the start button. sets the base for the stop watch and sets
        //values in the ViewModel to start the timer
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add the necessary implementation for starting the timer
                if (!sweatyViewModel.isStopwatchRunning()) {
                    Log.d("DEBUG", "onClick: start");
                    stopwatch.setBase(SystemClock.elapsedRealtime() - sweatyViewModel.getOffset());
                    stopwatch.start();
                    sweatyViewModel.setStopwatchRunning(true);

                }
            }
        });

        //listener for the pause button. This stops the stopwatch and updates values in the
        //view model to stop the timer
        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sweatyViewModel.isStopwatchRunning()) {
                    sweatyViewModel.setOffset(SystemClock.elapsedRealtime() - stopwatch.getBase());
                    stopwatch.stop();
                    sweatyViewModel.setStopwatchRunning(false);
                }
            }
        });

        //listener for the reset button
        //resets the laps counter and laps
        //resets the timer
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopwatch.setBase(SystemClock.elapsedRealtime());
                sweatyViewModel.setOffset(0);
                sweatyViewModel.setLapCounter(1);
                clearLaps();
            }
        });

        //listener for the lap button
        //calls addLap function
        lapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sweatyViewModel.isStopwatchRunning()) {
                    addLap();
                }
            }
        });

        //listener for clear laps button
        //calls clearLaps function
        clearLapsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearLaps();
            }
        });

        return view;
    }

    //function to add a lap
    //creates a new text view and sets the text by retriving the lap time and lap count.
    private void addLap() {
        TextView lapTextView = new TextView(getContext());
        lapTextView.setText("Lap " + sweatyViewModel.getLapCounter() + ": " + stopwatch.getText());
        lapLayout.addView(lapTextView);
        sweatyViewModel.setLapCounter(sweatyViewModel.getLapCounter() + 1);
    }

    //removes the view for the laps so the laps are cleared and resets the lap counter
    private void clearLaps() {
        lapLayout.removeAllViews();
        sweatyViewModel.setLapCounter(1);
    }


    //bundling values to restore them when the activity is refreshed
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save the current state of the Chronometer
        outState.putLong("baseTime", stopwatch.getBase());
        outState.putBoolean("isStopwatchRunning", sweatyViewModel.isStopwatchRunning());
    }
}