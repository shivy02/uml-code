/*
File Name: CalendarFragment.java
Purpose:  this code creates a fragment with a calendar, and when the user selects a date,
it updates and displays a corresponding to-do list. The to-do list items are hardcoded based
on the selected day of the week for simplicity. The RecyclerView is implemented using View Binding
for improved efficiency and readability.
*/
package com.mobileapp.sweatbox;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mobileapp.sweatbox.databinding.FragmentCalendarBinding;
import com.mobileapp.sweatbox.databinding.TodoItemLayoutBinding;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CalendarFragment extends Fragment {

    private FragmentCalendarBinding binding;
    private List<String> todoList;
    private TodoAdapter todoAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout using View Binding
        binding = FragmentCalendarBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        // Initialize the to-do list and the adapter
        todoList = new ArrayList<>();
        todoAdapter = new TodoAdapter(todoList);

        // Set up the RecyclerView
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerView.setAdapter(todoAdapter);

        // Set a listener for date changes in the calendar
        binding.calendarView.setOnDateChangeListener((calendarView, year, month, day) -> {
            // Handle date selection
            String dayOfWeek = getDayOfWeek(year, month, day);
            String selectedDate = year + "-" + (month + 1) + "-" + day;
            // Uncomment the line below if you want to display a toast message
            // Toast.makeText(requireContext(), "Selected Date: " + selectedDate + ", Day of Week: " + dayOfWeek, Toast.LENGTH_SHORT).show();
            updateTodoListForDate(dayOfWeek);
        });

        return view;
    }

    // Method to get the day of the week for a given date
    private String getDayOfWeek(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);
        Date date = calendar.getTime();

        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
        return dayFormat.format(date);
    }

    // Method to update the to-do list based on the selected date
    private void updateTodoListForDate(String dayOfWeek) {
        // Logic to fetch and update to-do list for the selected date
        // For simplicity, adding dummy data here
        todoList.clear();
        switch (dayOfWeek) {
            case "Monday":
                String pushStuff = getString(R.string.pushstuff);
                todoList.add(pushStuff);
                break;
            case "Tuesday":
                String pullStuff = getString(R.string.pullstuff);
                todoList.add(pullStuff);
                break;
            case "Wednesday":
                String legStuff = getString(R.string.legstuff);
                todoList.add(legStuff);
                break;
            case "Thursday":
                String pushStuffThursday = getString(R.string.pushstuff);
                todoList.add(pushStuffThursday);
                break;
            case "Friday":
                String pullStuffFriday = getString(R.string.pullstuff);
                todoList.add(pullStuffFriday);
                break;
            case "Saturday":
                String legStuffSaturday = getString(R.string.legstuff);
                todoList.add(legStuffSaturday);
                break;
            case "Sunday":
                String rest = getString(R.string.rest);
                todoList.add(rest);
                break;
        }
        todoAdapter.notifyDataSetChanged();
    }

    // Adapter for the to-do list RecyclerView
    private static class TodoAdapter extends RecyclerView.Adapter<TodoAdapter.TodoViewHolder> {

        private final List<String> todoList;

        TodoAdapter(List<String> todoList) {
            this.todoList = todoList;
        }

        @NonNull
        @Override
        public TodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // Inflate the item layout using View Binding
            TodoItemLayoutBinding binding = TodoItemLayoutBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new TodoViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull TodoViewHolder holder, int position) {
            // Bind data to the ViewHolder
            holder.binding.todoText.setText(todoList.get(position));
        }

        @Override
        public int getItemCount() {
            return todoList.size();
        }

        static class TodoViewHolder extends RecyclerView.ViewHolder {

            TodoItemLayoutBinding binding;

            TodoViewHolder(TodoItemLayoutBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }
        }
    }
}
