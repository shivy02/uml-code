package com.mobileapp.sweatbox;

import androidx.lifecycle.ViewModel;

public class SweatyViewModel extends ViewModel {
    //timer stuff
    private long offset = 0;
    private boolean isStopwatchRunning = false;
    private int lapCounter = 1;

    //profile stuff
    // Define keys for fields
    public static final String NAME = "name";
    public static final String HEIGHT = "height";
    public static final String WEIGHT = "weight";
    public static final String BIRTHDAY = "birthday";
    public static final String CALORIE_GOAL = "calorie_goal";

    // Fields for user's profile information
    private String name = "";
    private String height = "";
    private String weight = "";
    private String birthday = "";
    private String calorieGoal = "";


    public long getOffset() {
        return offset;
    }

    public void setOffset(long offset) {
        this.offset = offset;
    }

    public boolean isStopwatchRunning() {
        return isStopwatchRunning;
    }

    public void setStopwatchRunning(boolean stopwatchRunning) {
        isStopwatchRunning = stopwatchRunning;
    }

    public int getLapCounter() {
        return lapCounter;
    }

    public void incrementLapCounter() {
        lapCounter++;
    }

    public void setLapCounter(int lapCounter) {
        this.lapCounter = lapCounter;
    }
    // Getter methods
    public String getName() {
        return name;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getCalorieGoal() {
        return calorieGoal;
    }

    // Setter methods
    public void setName(String name) {
        this.name = name;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setCalorieGoal(String calorieGoal) {
        this.calorieGoal = calorieGoal;
    }
}
